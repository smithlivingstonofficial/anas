<?php
// Include the database connection
include 'db_connection.php'; // Make sure the correct path is given to your db_connection.php file

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the email and new status from the POST data
    $email = $_POST['email'];
    $new_status = $_POST['status'];

    // Prepare and execute the SQL query to update the order status by email
    $updateQuery = "UPDATE orders o
                    JOIN order_items oi ON o.id = oi.order_id
                    SET o.status = ?
                    WHERE o.email = ?";

    if ($stmt = $conn->prepare($updateQuery)) {
        // Bind the parameters (s = string, s = string for email and status)
        $stmt->bind_param("ss", $new_status, $email);  // "ss" stands for string, string
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "<div class='alert alert-success'>Order status updated to " . htmlspecialchars($new_status) . " successfully!</div>";
        } else {
            echo "<div class='alert alert-error'>Error: No matching order found for the given email or status is already the same.</div>";
        }

        $stmt->close();  // Close the statement
    } else {
        echo "<div class='alert alert-error'>Error preparing statement: " . $conn->error . "</div>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Update Order Status</title>
</head>
<body>
    <div class="container">
        <h1>Update Order Status</h1>
        <form method="POST" action="admin_order_update.php">
            <label for="email">Customer Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="Pending">Pending</option>
                <option value="Shipped">Shipped</option>
                <option value="Delivered">Delivered</option>
                <option value="Canceled">Canceled</option>
            </select>

            <button type="submit">Update Status</button>
        </form>
    </div>
</body>
</html>

<style>
    /* Reset some default styles */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    /* Body and container styling */
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        padding: 20px;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }

    h1, h2, h3 {
        color: #333;
        margin-bottom: 15px;
    }

    h1 {
        font-size: 2rem;
    }

    /* Form styling */
    form {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    label {
        font-weight: bold;
    }

    input, select, button {
        padding: 10px;
        font-size: 1rem;
        border: 1px solid #ccc;
        border-radius: 5px;
        outline: none;
    }

    input:focus, select:focus, button:focus {
        border-color: #007BFF;
    }

    button {
        background-color: #007BFF;
        color: #fff;
        cursor: pointer;
    }

    button:hover {
        background-color: #0056b3;
    }

    /* Center content within the page */
    .center {
        text-align: center;
    }

    /* Styling for messages and alerts */
    .alert {
        padding: 15px;
        margin: 20px 0;
        border-radius: 5px;
    }

    .alert-success {
        background-color: #28a745;
        color: white;
    }

    .alert-error {
        background-color: #dc3545;
        color: white;
    }

    /* Responsive styling for smaller screens */
    @media (max-width: 768px) {
        .container {
            padding: 15px;
        }

        form {
            gap: 10px;
        }

        h1 {
            font-size: 1.5rem;
        }
    }
</style>

<?php
// Include the database connection
include 'db_connection.php'; // Make sure the correct path is given to your db_connection.php file

// Initialize order variable
$order = null;
$items = [];

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email']) && !empty($_POST['email'])) {
    // Get the email from the POST request
    $email = $_POST['email'];

    // Query to fetch order details based on the email
    $query = "SELECT orders.id, orders.name, orders.email, orders.status, orders.order_date 
              FROM orders 
              WHERE orders.email = ?";

    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("s", $email);  // "s" stands for string
        $stmt->execute();
        $stmt->bind_result($id, $name, $email, $status, $order_date);

        // Fetch order details
        if ($stmt->fetch()) {
            $order = ['id' => $id, 'name' => $name, 'email' => $email, 'status' => $status, 'order_date' => $order_date];
        }
        $stmt->close();  // Close the statement
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

    // Fetch order items related to the email
    $itemsQuery = "SELECT order_items.product_id, order_items.quantity, order_items.total_price, products.name 
                   FROM order_items 
                   JOIN products ON order_items.product_id = products.id
                   JOIN orders ON order_items.order_id = orders.id
                   WHERE orders.email = ?";
    
    if ($stmt = $conn->prepare($itemsQuery)) {
        $stmt->bind_param("s", $email);  // "s" stands for string
        $stmt->execute();
        $stmt->bind_result($product_id, $quantity, $total_price, $product_name);

        // Fetch all order items
        while ($stmt->fetch()) {
            $items[] = ['product_id' => $product_id, 'quantity' => $quantity, 'total_price' => $total_price, 'name' => $product_name];
        }
        $stmt->close();  // Close the statement
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Tracking</title>
</head>
<body>
    <h1>Track Your Order</h1>
    <form method="POST" action="order_tracking.php">
        <label for="email">Customer Email:</label>
        <input type="email" id="email" name="email" required>
        <button type="submit">Track Order</button>
    </form>

    <?php if ($order): ?>
        <h2>Order Details</h2>
        <p><strong>Order ID:</strong> <?php echo htmlspecialchars($order['id']); ?></p>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($order['name']); ?></p>
        <p><strong>Status:</strong> <?php echo htmlspecialchars($order['status']); ?></p>
        <p><strong>Order Date:</strong> <?php echo htmlspecialchars($order['order_date']); ?></p>

        <h3>Order Items</h3>
        <table>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Total Price</th>
            </tr>
            <?php foreach ($items as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                    <td>$<?php echo htmlspecialchars($item['total_price']); ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>No order found for the given email.</p>
    <?php endif; ?>
</body>
</html>

<style>
    /* Reset some default styles */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    /* Body and container styling */
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        padding: 20px;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }

    h1, h2, h3 {
        color: #333;
        margin-bottom: 15px;
    }

    h1 {
        font-size: 2rem;
    }

    /* Form styling */
    form {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    label {
        font-weight: bold;
    }

    input, select, button {
        padding: 10px;
        font-size: 1rem;
        border: 1px solid #ccc;
        border-radius: 5px;
        outline: none;
    }

    input:focus, select:focus, button:focus {
        border-color: #007BFF;
    }

    button {
        background-color: #007BFF;
        color: #fff;
        cursor: pointer;
    }

    button:hover {
        background-color: #0056b3;
    }

    /* Table styling for order details */
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    table th, table td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    table th {
        background-color: #007BFF;
        color: white;
    }

    /* Center content within the page */
    .center {
        text-align: center;
    }

    /* Styling for messages and alerts */
    .alert {
        padding: 15px;
        margin: 20px 0;
        border-radius: 5px;
    }

    .alert-success {
        background-color: #28a745;
        color: white;
    }

    .alert-error {
        background-color: #dc3545;
        color: white;
    }

    /* Responsive styling for smaller screens */
    @media (max-width: 768px) {
        .container {
            padding: 15px;
        }

        form {
            gap: 10px;
        }

        h1 {
            font-size: 1.5rem;
        }

        table th, table td {
            padding: 8px;
        }
    }
</style>
